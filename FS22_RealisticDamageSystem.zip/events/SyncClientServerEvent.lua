-- Contact: RealisticDamageSystem@web.de
-- Date 1.11.2022

SyncClientServerEvent = {}

local SyncClientServerEvent_mt = Class(SyncClientServerEvent, Event)
InitEventClass(SyncClientServerEvent, "SyncClientServerEvent")




---Create instance of Event class
-- @return table self instance of class event
function SyncClientServerEvent.emptyNew()
    local self = Event.new(SyncClientServerEvent_mt)
    return self
end


---Create new instance of event
-- @param table vehicle vehicle
-- @param integer state state
function SyncClientServerEvent.new(vehicle, DamagesAtFirstStart, BackupAgeXML, DamagesAfterInspection, DamagesBeforeMaintenance, RepairedDamages, DifferenzNextInspectionMonths, CompareDamagesForWear, FinishDay, FinishHour, FinishMinute, BackupOperatingTimeXML, DontAllowXmlNumberReset, MaintenanceActive, InspectionActive, CVTRepairActive, LengthForDamages)
    local self = SyncClientServerEvent.emptyNew()
   
    self.DamagesAtFirstStart = DamagesAtFirstStart
	self.BackupAgeXML = BackupAgeXML
	self.DamagesAfterInspection = DamagesAfterInspection
	self.DamagesBeforeMaintenance = DamagesBeforeMaintenance
	self.RepairedDamages = RepairedDamages
	self.DifferenzNextInspectionMonths = DifferenzNextInspectionMonths
	self.CompareDamagesForWear = CompareDamagesForWear
	self.FinishDay = FinishDay
	self.FinishHour = FinishHour
	self.FinishMinute = FinishMinute

	self.BackupOperatingTimeXML = BackupOperatingTimeXML

	self.DontAllowXmlNumberReset = DontAllowXmlNumberReset
	self.MaintenanceActive = MaintenanceActive
	self.InspectionActive = InspectionActive
	self.CVTRepairActive = CVTRepairActive

	self.LengthForDamages = LengthForDamages
    
    self.vehicle = vehicle
    return self
end


---Called on client side on join
-- @param integer streamId streamId
-- @param integer connection connection
function SyncClientServerEvent:readStream(streamId, connection)
    self.vehicle = NetworkUtil.readNodeObject(streamId)

    self.DamagesAtFirstStart = streamReadInt32(streamId)
    self.BackupAgeXML = streamReadInt32(streamId)
    self.DamagesAfterInspection = streamReadInt32(streamId)
    self.DamagesBeforeMaintenance = streamReadInt32(streamId)
    self.RepairedDamages = streamReadInt32(streamId)
    self.DifferenzNextInspectionMonths = streamReadInt32(streamId)
    self.CompareDamagesForWear = streamReadInt32(streamId)
    self.FinishDay = streamReadInt32(streamId)
    self.FinishHour = streamReadInt32(streamId)
    self.FinishMinute = streamReadInt32(streamId)

    self.BackupOperatingTimeXML = streamReadFloat32(streamId)

	self.DontAllowXmlNumberReset = streamReadBool(streamId)
	self.MaintenanceActive = streamReadBool(streamId)
	self.InspectionActive = streamReadBool(streamId)
	self.CVTRepairActive = streamReadBool(streamId)

	self.LengthForDamages = streamReadString(streamId)

    self:run(connection)
end


---Called on server side on join
-- @param integer streamId streamId
-- @param integer connection connection
function SyncClientServerEvent:writeStream(streamId, connection)
    NetworkUtil.writeNodeObject(streamId, self.vehicle)

    streamWriteInt32(streamId, self.DamagesAtFirstStart)
	streamWriteInt32(streamId, self.BackupAgeXML)
	streamWriteInt32(streamId, self.DamagesAfterInspection)
	streamWriteInt32(streamId, self.DamagesBeforeMaintenance)
	streamWriteInt32(streamId, self.RepairedDamages)
	streamWriteInt32(streamId, self.DifferenzNextInspectionMonths)
	streamWriteInt32(streamId, self.CompareDamagesForWear)
	streamWriteInt32(streamId, self.FinishDay)
	streamWriteInt32(streamId, self.FinishHour)
	streamWriteInt32(streamId, self.FinishMinute)
	
	streamWriteFloat32(streamId, self.BackupOperatingTimeXML)

	streamWriteBool(streamId, self.DontAllowXmlNumberReset)
	streamWriteBool(streamId, self.MaintenanceActive)
	streamWriteBool(streamId, self.InspectionActive)
	streamWriteBool(streamId, self.CVTRepairActive)

	streamWriteString(streamId, self.LengthForDamages)
end


---Run action on receiving side
-- @param integer connection connection
function SyncClientServerEvent:run(connection)
    if self.vehicle ~= nil and self.vehicle:getIsSynchronized() then
        RealisticDamageSystem.SyncClientServer(self.vehicle, self.DamagesAtFirstStart, self.BackupAgeXML, self.DamagesAfterInspection, self.DamagesBeforeMaintenance, self.RepairedDamages, self.DifferenzNextInspectionMonths, self.CompareDamagesForWear, self.FinishDay, self.FinishHour, self.FinishMinute, self.BackupOperatingTimeXML, self.DontAllowXmlNumberReset, self.MaintenanceActive, self.InspectionActive, self.CVTRepairActive, self.LengthForDamages)
		
		if not connection:getIsServer() then
			g_server:broadcastEvent(SyncClientServerEvent.new(self.vehicle, self.DamagesAtFirstStart, self.BackupAgeXML, self.DamagesAfterInspection, self.DamagesBeforeMaintenance, self.RepairedDamages, self.DifferenzNextInspectionMonths, self.CompareDamagesForWear, self.FinishDay, self.FinishHour, self.FinishMinute, self.BackupOperatingTimeXML, self.DontAllowXmlNumberReset, self.MaintenanceActive, self.InspectionActive, self.CVTRepairActive, self.LengthForDamages), nil, connection, self.vehicle)
		end
    end
end