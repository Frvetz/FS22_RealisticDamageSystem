-- by Frvetz
-- Contact: RealisticDamageSystem@gmail.com
-- Date 2.12.2021

RealisticDamageSystemMotorStartDialog = {};
RealisticDamageSystemMotorStartDialog.l10nEnv = "FS19_RealisticDamageSystemMotorStartDialog";   
 
 
function RealisticDamageSystemMotorStartDialog:loadMap(name)
   RealisticDamageSystemMotorStartDialog.automaticMotorStartEnabledBackup = g_currentMission.missionInfo.automaticMotorStartEnabled
  -- g_currentMission.inGameMenu.pageSettingsGame.checkAutoMotorStart.onClickCallback = RealisticDamageSystem:DIALOG_MOTORSTART()
end

function RealisticDamageSystemMotorStartDialog:update(dt)
   -- g_currentMission.inGameMenu.pageSettingsGame.checkAutoMotorStart.onClickCallback = RealisticDamageSystem:DIALOG_MOTORSTART()
	--local automaticMotorStartEnabledBackup = g_currentMission.missionInfo.automaticMotorStartEnabled
    if g_currentMission.missionInfo.automaticMotorStartEnabled ~= RealisticDamageSystemMotorStartDialog.automaticMotorStartEnabledBackup then
	    RealisticDamageSystemMotorStartDialog.automaticMotorStartEnabledBackup = g_currentMission.missionInfo.automaticMotorStartEnabled
		RealisticDamageSystem:DIALOG_MOTORSTART()
    end
--print("automaticMotorStartEnabledBackup: "..tostring( RealisticDamageSystemMotorStartDialog.automaticMotorStartEnabledBackup))
--print("automaticMotorStartEnabled: "..tostring(g_currentMission.missionInfo.automaticMotorStartEnabled))
end 


function RealisticDamageSystem:DIALOG_MOTORSTART()
    --if not RealisticDamageSystem.eventActive or self.spec_RealisticDamageSystem == nil then 
	--	return; 
	--end
	if g_currentMission.missionInfo.automaticMotorStartEnabled == true and g_server ~= nil then
		g_gui:showInfoDialog({text = g_i18n:getText("dialog_AutoMotorStart", RealisticDamageSystemMotorStartDialog.l10nEnv)})
	end	   


	--print(g_currentMission.missionInfo.automaticMotorStartEnabled)
end
addModEventListener(RealisticDamageSystemMotorStartDialog)